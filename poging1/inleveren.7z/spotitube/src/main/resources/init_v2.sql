CREATE TABLE User (
  username TEXT,
  password TEXT,
  token TEXT,
  CONSTRAINT PRIMARY KEY (username)
)
