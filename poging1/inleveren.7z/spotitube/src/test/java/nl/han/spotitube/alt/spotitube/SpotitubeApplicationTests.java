package nl.han.spotitube.alt.spotitube;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpotitubeApplicationTests {

	@Test
	void contextLoads() {
	}

}
